<?php

$meta['backupnamespace'] = array('string');
$meta['filterdirs'] = array('');
$meta['filterbackups'] = array('onoff');
