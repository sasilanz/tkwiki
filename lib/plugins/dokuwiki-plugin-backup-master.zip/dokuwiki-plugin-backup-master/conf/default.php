<?php

$conf['backupnamespace'] = 'wiki:backup';
$conf['filterdirs'] = '/path/to/my/dokuwiki/data/media/latex';
$conf['filterbackups'] = true;
